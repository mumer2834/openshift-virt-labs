# Lab 4 — Snapshots, clones, and real backup

## Storage budget — check before you start

This lab provisions more storage than any other. On a small cluster, work out whether it
fits before you begin rather than discovering it at the OADP restore.

| Step | Provisions | Real cost |
|---|---|---|
| `01-snapshot` | VolumeSnapshot of the VM disk | ~0, grows as the origin diverges |
| `02-restore` | New PVC from the snapshot | 0 if your CSI driver does thin restores, otherwise a full copy |
| `03-clone` | A whole second VM | A full disk copy unless `cloneStrategy` is `csi-clone` or `snapshot` |
| `04-dataimportcron` | A second boot image, times `importsToKeep` | ~10Gi per retained import |
| `minio-data` | 40Gi PVC (Filesystem) | only what the backups actually write |
| OADP backup | VM disk copied into MinIO | the used size of the disk |
| OADP restore | Another full volume | the used size of the disk |

Rough total: **60–145Gi**, and which end you land on is decided almost entirely by one
value:

```bash
oc get storageprofile <your-class> -o jsonpath='{.status.cloneStrategy}{"\n"}'
oc get volumesnapshotclass
```

- `csi-clone` or `snapshot` — the array does the work. Fast, and shares blocks.
- `copy` — CDI runs a host byte-for-byte copy of the **whole device**, zeros included. A
  30Gi disk costs 30Gi of real space and takes minutes to tens of minutes.

**If you get `copy` but a VolumeSnapshotClass exists for your driver, you can probably fix
it.** The profile is computed when the class is first seen, so a snapshot class added later
leaves it stale. Override it:

```bash
oc get volumesnapshotclass                           # one for your driver?
oc patch storageprofile <your-class> --type=merge \
  -p '{"spec":{"cloneStrategy":"snapshot"}}'
oc get storageprofile <your-class> \
  -o jsonpath='spec={.spec.cloneStrategy} status={.status.cloneStrategy}{"\n"}'
```

Measured on LVMS/topolvm, a 5Gi clone went from a multi-minute byte copy to **12 seconds**,
using almost no extra space. That single field decides whether this lab is comfortable or
impossible on a small cluster — check it first.

On `copy` with limited storage — and no way to switch to snapshot — either do the steps one
at a time and delete each artifact before the next, or skip `03-clone` and
`04-dataimportcron` and read them instead of applying them. `04-dataimportcron` in particular imports a *second* copy of an image
your cluster probably already has — check `oc get dataimportcron -A` first, and consider
inspecting the existing one rather than creating another.

Clean up as you go:

```bash
oc delete vmsnapshot web01-pre-patch -n production-vms      # after the restore
oc delete vm rhel9-web03 -n production-vms                  # after the clone
oc delete dv <restored> -n production-vms
```

See `reference/troubleshooting.md` for what running out mid-copy looks like — it does not
produce a clear error, it produces a loop.


## Four things people call "backup"

| | What it is | Survives... | Use it for |
|---|---|---|---|
| **Snapshot** | Point-in-time state, same storage | A bad patch. Not storage loss, not namespace deletion | Short rollback before a risky change |
| **Clone** | New independent copy | Nothing — it's a copy, not a restore point | Duplicating for test, seeding a golden image |
| **Template** | Reusable definition + boot source | N/A — no data in it | Standardising how VMs get built |
| **Backup (OADP)** | Objects + disk data in external object storage | Namespace deletion, storage loss, cluster loss | Actual disaster recovery |

A snapshot on the same storage as the VM is not a disaster recovery plan. It is a
convenience.

## Snapshots and clones

```bash
oc apply -f 01-snapshot.yaml
oc get virtualmachinesnapshot -n production-vms -w

# Rollback (VM must be stopped)
virtctl stop rhel9-web01 -n production-vms
oc apply -f 02-restore.yaml
oc get virtualmachinerestore -n production-vms -w
virtctl start rhel9-web01 -n production-vms
```

Clone:

```bash
oc apply -f 03-clone.yaml
oc get virtualmachineclone -n production-vms -w
```

Check which clone strategy you're actually getting — if cloning 30 GiB takes 20 minutes,
you're on `copy` and probably don't have to be:

```bash
oc get storageprofile lvms-vg1 -o yaml | grep -A2 cloneStrategy
```

## OADP — the one that's actually a backup

```bash
# 1. Object storage
oc apply -f minio/01-minio.yaml
./minio/02-create-bucket.sh

# 2. Operator
oc apply -f oadp/00-install-operator.yaml
oc get csv -n openshift-adp -w

# 3. Credentials + configuration
./oadp/01-create-secret.sh
oc apply -f oadp/02-dpa.yaml

# 4. MUST say Available before going further
oc get backupstoragelocation -n openshift-adp
```

## Prove the backup works: destroy something, get it back

```bash
# Write a marker inside the guest so you can prove the data came back
virtctl console rhel9-web01 -n production-vms
#   echo "restore-test-$(date +%s)" | sudo tee /data/marker.txt
#   cat /data/marker.txt      <- remember this value
#   sudo sync                 <- IMPORTANT, see below

# Back up
oc apply -f oadp/03-backup.yaml
oc get backup -n openshift-adp -w          # wait for Completed

# Destroy it for real
oc delete vm rhel9-web01 -n production-vms
oc delete pvc --all -n production-vms
oc get all,pvc -n production-vms           # confirm it's gone

# Restore
oc apply -f oadp/04-restore.yaml
oc get restore -n openshift-adp -w

# VERIFY FROM INSIDE THE GUEST — this is the only step that proves anything
virtctl start rhel9-web01 -n production-vms
virtctl console rhel9-web01 -n production-vms
#   sudo mount /dev/<dev> /data
#   cat /data/marker.txt
```

A Restore object saying `Completed` is a statement about Kubernetes. Your file being
readable is a statement about your business. Only one of those is a backup.

## Where it goes wrong

| Symptom | Cause |
|---|---|
| BSL not `Available` | Secret missing, or its key isn't named `cloud` |
| Backup `PartiallyFailed` | Usually no VolumeSnapshotClass. `oc get volumesnapshotclass` |
| Backup `Completed`, no volume data | `nodeAgent.enable` false, or `snapshotVolumes: false` with no fs backup |
| Restore `Completed`, VM won't start | PVC still binding. Watch `oc get pvc -n production-vms` |
| **Marker file missing after restore** | You wrote it but never ran `sync` — it was still in page cache when the snapshot was taken |

That last one is the most instructive failure here. The file existed. The backup
succeeded. The data wasn't there. That gap — between what the control plane reports and
what is actually on disk — is the whole argument for the guest agent and filesystem
freeze.

## Backup data paths

| Path | Speed | Protects against |
|---|---|---|
| CSI snapshot | fastest | A bad change. **Not** array loss — the data never left it |
| CSI snapshot + Data Mover | fast | Array loss, cluster loss. This is what you want for DR |
| Filesystem backup (Kopia) | slowest | Same, and works without CSI snapshot support |

The question to ask your storage team: can we take CSI snapshots, and can we move them off
the array? The answer determines your real recovery capability.
