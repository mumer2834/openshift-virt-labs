#!/usr/bin/env bash
# The DPA never goes Available without this.
# The key MUST be named "cloud" -- this is the single most common mistake.
set -eu
cd "$(dirname "$0")"
oc create secret generic cloud-credentials \
  -n openshift-adp \
  --from-file cloud=./credentials-velero \
  --dry-run=client -o yaml | oc apply -f -
oc get secret cloud-credentials -n openshift-adp
