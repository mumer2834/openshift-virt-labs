#!/usr/bin/env bash
set -eu
oc -n minio rollout status deploy/minio --timeout=180s
oc -n minio exec deploy/minio -- mc alias set local http://localhost:9000 minio minio123
oc -n minio exec deploy/minio -- mc mb --ignore-existing local/ocpv-backups
oc -n minio exec deploy/minio -- mc ls local/
