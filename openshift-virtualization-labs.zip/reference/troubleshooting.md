# Troubleshooting

## Cold start — cluster was powered off

The most common problem with a cluster that gets stopped and started again.

**Symptoms:** nodes `NotReady`, operators degraded, `oc` times out or returns
certificate errors.

**Cause:** while the node was off, its kubelet certificates expired or rotated. On
startup it requests new ones, but the approver can't run because the cluster isn't
healthy — chicken and egg.

**Fix** — on a control-plane node itself, not your workstation. Your normal kubeconfig
won't authenticate in this state, so use the localhost-recovery one:

```bash
ssh core@<node-address>
sudo -i
export KUBECONFIG=/etc/kubernetes/static-pod-resources/kube-apiserver-certs/secrets/node-kubeconfigs/localhost-recovery.kubeconfig

oc get csr

oc get csr -o go-template='{{range .items}}{{if not .status}}{{.metadata.name}}{{"\n"}}{{end}}{{end}}' \
  | xargs --no-run-if-empty oc adm certificate approve
```

**Run it two or three times, a minute apart.** Approval comes in waves — the kubelet
client CSR first, then the node requests a serving certificate, which generates a fresh
batch.

Then wait. Ten minutes is normal before operators settle.

```bash
oc get nodes
oc get co
```

`scripts/cold-start.sh` does the approval loop for you.

**Avoiding it:** if you need the cluster available at a specific time, leave it running
rather than stopping it the night before. Recovery is reliable but not instant — budget
15 minutes.

---

## VM won't start

```bash
oc get vm,vmi,pod -n <ns> -l kubevirt.io/domain=<vm>
oc describe vmi <vm> -n <ns>
oc get dv -n <ns>                    # disk problems surface HERE, not on the VM
```

| Symptom | Cause |
|---|---|
| Pending forever, no useful event | DataVolume can't bind — check `oc get sc` for a default |
| `interfaces`/`networks` mismatch | They pair by name. A typo means the VM never starts |
| No `kubevirt.io/schedulable` node | The node can't expose `/dev/kvm`. On bare metal, enable VT-x/AMD-V in firmware. On a nested setup, the node VM needs host CPU passthrough and nested virtualization enabled on the hypervisor |
| ImagePullBackOff on importer | No pull secret for registry.redhat.io, or no outbound network |

---

## DataVolume clone restarts near 100%

**Symptom:** `oc get dv` shows `CloneInProgress` climbing to ~95%, then `RESTARTS`
increments and progress resets to near zero. Loops indefinitely. Often nothing obvious in
the target namespace's events.

**Cause:** the storage backing the target ran out of *real* space. Two things conspire:

1. **A host-assisted clone of a `Block` volume copies the whole device, zeros included.**
   A 30Gi clone of a RHEL image holding 10Gi of data still writes 30Gi. People size for
   the data, not the device.
2. Thin provisioning lets the PVC be created at full size, so nothing fails until the copy
   writes the last of it — which is why it dies at the end, not the start.

Then it loops, because CDI's restart deletes the partial target and **frees the space**,
so the retry has room to fill it again.

### Measuring it is harder than it looks

```bash
NODE=$(oc get node -o name | head -1 | cut -d/ -f2)
oc debug node/$NODE -- chroot /host lvs -a      # thin pool Data%
```

**A one-off reading will often look fine.** If you check just after a reset, the partial
target has already been deleted and the pool reads low. Watch it over a cycle instead:

```bash
for i in $(seq 1 30); do
  oc debug node/$NODE -- chroot /host lvs --noheadings -o lv_name,data_percent vg1/thin-pool-1
  sleep 20
done
```

If it climbs toward 100 and then drops back, that is the loop.

Better still, do the arithmetic. Add up what the pool already holds, add the **full
provisioned size** of every clone you are about to start, and compare with the pool:

```bash
oc debug node/$NODE -- chroot /host lvs -a            # per-volume Data% x LSize = real use
oc get pvc -A -o custom-columns=NS:.metadata.namespace,NAME:.metadata.name,\
SIZE:.spec.resources.requests.storage,SC:.spec.storageClassName
```

Also check `oc describe node $NODE | grep -A8 Conditions` for `DiskPressure`, and look for
events in the **source** namespace — a host-assisted clone runs a source pod beside the
golden image and the failure often surfaces there:

```bash
oc get events -n openshift-virtualization-os-images --sort-by=.lastTimestamp | tail -30
oc describe dv <name> -n <ns> | tail -40
```

### Reclaim space: unused golden images are usually the biggest win

`enableCommonBootImageImport` imports **every** common boot source — CentOS Stream 9 and
10, Fedora, RHEL 8, 9 and 10. That is six 30Gi volumes for images you will mostly never
boot, and on a small cluster it is the single largest consumer.

Keep only what you use. Disable the others in the HyperConverged CR — deleting the
DataVolumes alone does not work, the cron re-imports them:

```bash
oc get dataimportcron -n openshift-virtualization-os-images      # exact names
oc explain hco.spec.workloadSources.dataImportCronTemplates 2>/dev/null \
  || oc explain hco.spec.dataImportCronTemplates                 # which path your build takes
oc edit hyperconverged kubevirt-hyperconverged -n openshift-cnv
```

```yaml
spec:
  dataImportCronTemplates:     # or spec.workloadSources.dataImportCronTemplates
    - metadata:
        name: fedora-image-cron
        annotations:
          dataimportcrontemplate.kubevirt.io/enable: 'false'
```

Name and annotation are all that is required. Then delete the leftover DataVolumes.

### First, check whether you need to copy at all

```bash
oc get storageprofile <your-class> -o jsonpath='{.status.cloneStrategy}{"\n"}'
oc get volumesnapshotclass
```

`copy` **plus** a VolumeSnapshotClass for your driver means the profile is stale — it is
computed when the class is first seen, so one added later doesn't change it. Override it
and the problem disappears rather than needing to be worked around:

```bash
oc patch storageprofile <your-class> --type=merge \
  -p '{"spec":{"cloneStrategy":"snapshot"}}'
```

A smart clone shares extents instead of copying bytes, so it costs almost no space and
completes in seconds. Measured on LVMS/topolvm: a 5Gi clone went from a multi-minute copy
to 12 seconds. Revert with:

```bash
oc patch storageprofile <your-class> --type=json \
  -p '[{"op":"remove","path":"/spec/cloneStrategy"}]'
```

### Other fixes, in order

1. Delete DataVolumes and VMs you no longer need, and clean up between labs rather than
   letting every lab's artifacts accumulate.
2. Clone one VM at a time. Two 30Gi copies in parallel need 60Gi of real space at once.
3. Skip cloning where the disk is not the point — see
   `lab03-networking/03-vm-dual-nic-containerdisk.yaml`.

**Shrinking the request does not help.** CDI requires the clone target to be at least the
size of the source, so you cannot ask for less than the golden image.

**Delete the VMs to stop the loop** before investigating; it keeps hammering the disk
otherwise.

```bash
oc delete vm <a> <b> -n <ns>
```

---

## Storage

```bash
oc get sc
oc get volumesnapshotclass
oc get storageprofile <your-class> -o yaml | grep -A5 -E 'cloneStrategy|claimPropertySets'
oc get pvc -A | grep -v Bound
```

If your storage is ReadWriteOnce only — LVMS and most cloud block storage are —
`ReadWriteMany` in any manifest will fail to bind. See `PLACEHOLDERS.md`.

---

## Useful one-liners

```bash
# Unhealthy operators only
oc get co --no-headers | awk '$3!="True" || $4!="False" || $5!="False"'

# What's eating the node
oc adm top node
oc adm top pod -A --sort-by=memory | head -20

# VM placement and IPs
oc get vmi -A -o custom-columns=\
NS:.metadata.namespace,NAME:.metadata.name,PHASE:.status.phase,\
IP:.status.interfaces[0].ipAddress,NODE:.status.nodeName

# Events, newest last
oc get events -n <ns> --sort-by=.lastTimestamp | tail -30

# Is the virt stack actually healthy
oc get pods -n openshift-cnv | grep -v Running | grep -v Completed
```
