# Command Reference
## OpenShift Virtualization — the commands you'll actually use

The distinction that matters: **`oc` operates on Kubernetes objects. `virtctl` operates on
the virtual machine.** `oc delete vm` removes an object. `virtctl stop` turns off a computer.
Mixing the two mental models causes real mistakes.

Most commands below take `-n <namespace>`. Omitted for brevity.

---

## Install and health

```bash
# Did the operator install?
oc get csv -n openshift-cnv

# Is it actually reconciled? All three conditions matter --
# Available=True on its own is not enough.
oc get hyperconverged kubevirt-hyperconverged -n openshift-cnv \
  -o jsonpath='{range .status.conditions[*]}{.type}={.status}{"\n"}{end}'

# Control plane pods
oc get pods -n openshift-cnv

# Will this node actually accept a VM? If empty, nothing will ever schedule.
oc get nodes -l kubevirt.io/schedulable=true

# Node-level agent logs (first stop when a VM won't start on one node)
oc logs -n openshift-cnv -l kubevirt.io=virt-handler --tail=50

# What API versions does THIS cluster use?
oc api-resources | grep -iE 'kubevirt|cdi|forklift|snapshot'
oc explain hyperconverged --api-version=hco.kubevirt.io/v1beta1
```

## The three objects

```bash
oc get vm       # definition   - persistent. Config problems live here.
oc get vmi      # instance     - ephemeral. Runtime problems live here.
oc get pod      # virt-launcher - the real process. Resource/scheduling problems live here.

# All three for one machine
oc get vm,vmi,pod -l kubevirt.io/domain=rhel9-web01

# Where is it running, and what IP did it get?
oc get vmi -o custom-columns=\
NAME:.metadata.name,PHASE:.status.phase,IP:.status.interfaces[0].ipAddress,NODE:.status.nodeName
```

## Power and lifecycle

```bash
virtctl start   rhel9-web01
virtctl stop    rhel9-web01                    # --grace-period=60 / --force
virtctl restart rhel9-web01
virtctl pause   rhel9-web01
virtctl unpause rhel9-web01
virtctl soft-reboot rhel9-web01                # ACPI reboot via guest agent
```

**runStrategy values** — set on the VM, not with these commands:

| Value | Behaviour |
|---|---|
| `Always` | Restart on any stop. **Shutting down from inside the guest does not keep it down.** |
| `RerunOnFailure` | Restart only on failure; clean guest shutdown stays down |
| `Manual` | No automatic action — you control state |
| `Halted` | Keep it stopped |

## Getting inside

```bash
virtctl console rhel9-web01          # serial. Ctrl+] to exit (not the window)
virtctl vnc     rhel9-web01          # graphical, needs a local VNC client
virtctl ssh     cloud-user@rhel9-web01
virtctl scp     ./file cloud-user@rhel9-web01:/tmp/
virtctl port-forward vm/rhel9-web01 8080:80

# Guest details -- returns nothing if qemu-guest-agent isn't installed.
# You need that agent for consistent backups and graceful shutdown.
virtctl guestosinfo rhel9-web01
virtctl fslist      rhel9-web01
virtctl userlist    rhel9-web01
```

## Disks

```bash
# Upload a local image as a DataVolume
virtctl image-upload dv rhel9-golden --size=30Gi \
  --image-path=./rhel9.qcow2 --insecure

# Hotplug. --persist writes it into the VM spec so it survives a restart.
# WITHOUT --persist the disk vanishes on the next reboot.
virtctl addvolume    rhel9-web01 --volume-name=data01 --persist
virtctl removevolume rhel9-web01 --volume-name=data01   # unmount in-guest first

# Watch an import -- problems surface on the DataVolume, not the VM
oc get dv -w
oc logs importer-<dv-name>
```

## Storage

```bash
oc get sc                                    # storage classes
oc get volumesnapshotclass                   # CSI snapshot support?
oc get storageprofile                        # what CDI picks by default

# Which clone strategy will you get? csi-clone > snapshot > copy (slow).
oc get storageprofile lvms-vg1 -o yaml | grep -A2 cloneStrategy

# Does a PVC support RWX? This decides whether live migration is possible.
# On THIS lab cluster the answer is always RWO (LVMS, single node).
oc get pvc <name> -o jsonpath='{.spec.accessModes}{"\n"}'
```

**The rule:** live migration requires `ReadWriteMany`, because two virt-launcher pods hold
the volume during the handover. No RWX means no non-disruptive node maintenance.

## Live migration and node maintenance

```bash
# BEFORE any maintenance: can everything on this node actually move?
oc get vmi --all-namespaces --field-selector spec.nodeName=worker-02

oc get vmi <name> -o jsonpath=\
'{.status.conditions[?(@.type=="LiveMigratable")]}{"\n"}'

# Trigger one by hand
virtctl migrate rhel9-web01

# Maintenance sequence
oc adm cordon worker-02
oc adm drain worker-02 --delete-emptydir-data --ignore-daemonsets --force
oc get virtualmachineinstancemigration -A -w      # watch them move
oc adm uncordon worker-02
```

**evictionStrategy** — set on the VM, or cluster-wide in the HyperConverged CR:

| Value | On drain |
|---|---|
| `LiveMigrate` | Migrate; if it can't, **block the drain** (this is a feature, not a fault) |
| `LiveMigrateIfPossible` | Migrate if possible, otherwise shut down and continue. Sensible default |
| `None` | Shut down with the node |
| `External` | Wait for an external controller |

Tuning lives in `HyperConverged.spec.liveMigrationConfig`:
`parallelMigrationsPerCluster`, `parallelOutboundMigrationsPerNode`,
`bandwidthPerMigration`, `completionTimeoutPerGiB`, `allowPostCopy`.

## Backup and restore (OADP)

```bash
# This must be Available or every backup will fail
oc get backupstoragelocation -n openshift-adp

oc get backup,restore -n openshift-adp
oc describe backup vmapp-backup -n openshift-adp

# With the velero CLI, if present
velero backup describe vmapp-backup --details
velero backup logs vmapp-backup
```

**Backup phases:** `Completed` means objects were captured. It says nothing about whether
your data is intact. **Always verify from inside the guest.**

| Data path | Speed | Protects against |
|---|---|---|
| CSI snapshot | fastest | A bad change. **Not** losing the array — the data never left it |
| CSI snapshot + Data Mover | fast | Array loss, cluster loss. This is what you want for DR |
| Filesystem backup (Kopia) | slowest | Same, and works without CSI snapshot support |

## Snapshots and clones (native, not OADP)

```bash
oc get virtualmachinesnapshot
oc get virtualmachinerestore
oc get virtualmachineclone

# Restore requires the VM to be stopped
virtctl stop rhel9-web01
oc apply -f restore.yaml
```

## MTV migration

```bash
oc get pods -n openshift-mtv
oc get provider -n openshift-mtv          # "host" = the local cluster, auto-registered
oc get networkmap,storagemap -n openshift-mtv
oc get plan -n openshift-mtv

# Why did validation fail? The message is specific -- read it.
oc get plan migrate-web-tier -n openshift-mtv -o jsonpath='{.status.conditions}' | jq

# Watch a migration
oc get plan migrate-web-tier -n openshift-mtv \
  -o jsonpath='{.status.migration.vms[*].phase}{"\n"}'
```

**Migration types:**

| Type | Downtime | Available from |
|---|---|---|
| Cold | Full copy duration | All supported sources |
| Warm | Minutes — final delta only | vSphere, oVirt |
| Live | Effectively none | **OpenShift to OpenShift only** |

## Networking

```bash
oc get nncp                  # what you asked for
oc get nnce                  # what actually happened, per node -- read failures here
oc get net-attach-def -n <ns>

# NADs are namespaced. A NAD in one project is invisible to a VM in another.
```

**The NetworkPolicy trap.** `NetworkPolicy` is enforced by the cluster CNI on the pod's
**primary** interface only. A VM with a bridged secondary interface bypasses it entirely — a
default-deny policy will apply cleanly and the VM will still talk to everything on that VLAN.
Nothing warns you.

For secondary interfaces you need `MultiNetworkPolicy`, which is off by default:

```bash
oc patch network.operator.openshift.io cluster --type=merge \
  -p '{"spec":{"useMultiNetworkPolicy":true}}'
```

## Troubleshooting quick table

| Symptom | Likely cause | First check |
|---|---|---|
| `virt-handler` CrashLoopBackOff on some nodes | No virtualization extensions there | `oc logs -n openshift-cnv <pod>` |
| VM `Pending` forever, no useful event | DataVolume can't bind — usually no default StorageClass | `oc get dv,pvc` then `oc get sc` |
| HyperConverged stuck `Progressing` | Operand can't reconcile, often node placement matching nothing | `oc get hco -o yaml`, read conditions |
| Console/VNC fail, VMs otherwise fine | `virt-api` unhealthy or webhook broken | `oc get pods -n openshift-cnv \| grep virt-api` |
| Live migration never starts | RWO storage, or no `evictionStrategy` | `LiveMigratable` condition on the VMI |
| Migration stalls near completion | Guest dirties pages faster than they copy | `completionTimeoutPerGiB`, consider `allowPostCopy` |
| Cloning is inexplicably slow | `copy` clone strategy | `oc get storageprofile <class> -o yaml` |
| Backup `Completed` but no volume data | `nodeAgent` disabled, or `snapshotVolumes: false` | DPA `nodeAgent.enable` |
| VM won't start after adding a NIC | `interfaces` and `networks` names don't pair | `oc describe vmi <name>` |
| Works on some nodes, not others | NNCP selector didn't match every node, or NIC name differs | `oc get nnce` |
| `virtctl` session hangs after closing the terminal | You didn't exit the console | Ctrl+] exits, not the window |

## Capacity planning

A VM costs more node resource than its guest spec says:

| What | Roughly |
|---|---|
| Infrastructure overhead per VM | ~200–300 MiB |
| Page tables | guest RAM ÷ 512 |
| Graphics device | ~16–32 MiB |
| Passthrough (VFIO/SR-IOV/GPU) | up to ~1 GiB |

Planning figures only. The authoritative number is the pod's own requests:

```bash
oc get pod virt-launcher-rhel9-web01-xxxxx \
  -o jsonpath='{.spec.containers[*].resources.requests}{"\n"}'
```

Budget roughly 10–15% above the sum of guest memory for a node's VM capacity, then measure.
