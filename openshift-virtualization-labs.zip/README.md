# Red Hat OpenShift Virtualization for Administrators
### Hands-on materials

Every manifest and command needed to build a working OpenShift Virtualization environment
and work through the five labs: operator deployment, VM provisioning, secondary
networking, backup and recovery, and workload migration.

Each lab is self-contained. Run them in order on a cluster you control.

Nothing here assumes a particular cluster, cloud, or installation method — the few values
that differ are `CHANGE_ME_*` placeholders. See **[PLACEHOLDERS.md](PLACEHOLDERS.md)**.

## Start here

The manifests use `CHANGE_ME_*` placeholders for the few values that differ between
clusters — storage class, access mode, volume mode, and one network interface name.

```bash
./scripts/configure.sh            # see what it detects on your cluster
./scripts/configure.sh --apply    # fill them in
```

See **[PLACEHOLDERS.md](PLACEHOLDERS.md)** for what each one means and how to choose.
`CHANGE_ME_ACCESSMODE` is the one worth thinking about — it decides whether live
migration works.

Then read **[SETUP-NOTES.md](SETUP-NOTES.md)**, which explains which labs need more than
one node and why.

## Versions

These manifests were written and tested against:

| Component | Version |
|---|---|
| OpenShift Container Platform | `FILL IN` |
| OpenShift Virtualization | `FILL IN` |
| Migration Toolkit for Virtualization | `FILL IN` |
| OADP | `FILL IN` |
| Storage | LVM Storage Operator, ReadWriteOnce (see below) |

Check yours before assuming these manifests apply unchanged:

```bash
./scripts/versions.sh
```

API groups move between releases. If a manifest is rejected:

```bash
oc api-resources | grep -iE 'kubevirt|cdi|forklift|snapshot|lvm'
oc explain <kind> --api-version=<group/version>
```

## Layout

```
scripts/              health check, version check, post-power-off recovery
lab01-operator/       install and verify OpenShift Virtualization
lab02-vms/            provision VMs from the CLI, hotplug a disk
lab03-networking/     Multus, bridges, and the NetworkPolicy trap
lab04-storage-backup/ snapshots, clones, OADP backup and restore
lab05-migration/      MTV between namespaces
reference/            command reference, troubleshooting
```

Files are numbered in apply order. **Read the comments** — several flag traps that cost
real time.

## Replicating this on your own cluster

Everything here works on a multi-node cluster too, and more of it works *better*.

1. Run `./scripts/configure.sh --apply`. If your storage supports RWX it will set
   `ReadWriteMany` automatically — that's the single most consequential value in the repo.
2. `lab02-vms/02-vm-rhel9.yaml` — add `evictionStrategy: LiveMigrate` to the VM spec.
3. Live migration and node drain become possible. The commands are in
   `reference/command-reference.md`.

## Lab shortcuts — not production settings

Marked `LAB ONLY` in the files:

- `insecureSkipTLSVerify: "true"` in the OADP DataProtectionApplication
- `insecureSkipVerify: "true"` in the MTV provider secret — use `cacert` instead
- Plain-text passwords in cloud-init `userData` — use a Secret
- `installPlanApproval: Automatic` — most production clusters want `Manual`
- MinIO with `minio`/`minio123` credentials

## Five things worth doing next

1. Find out whether your storage does ReadWriteMany and CSI snapshots. It constrains live
   migration, backup speed and clone performance — everything else follows from the answer.
2. Install the operator from YAML, not the console, so the manifests are in Git from day one.
3. Configure OADP and test a restore before you need one. Write down how long it took —
   that number is your RTO.
4. Build one golden image properly: hardened, guest agent installed, published as a
   DataSource.
5. Run one migration end to end on a non-critical VM, including the post-migration checklist.

If you only do one, make it the first — it constrains everything else.

## Two things people get wrong

**Live migration requires ReadWriteMany.** Two virt-launcher pods hold the volume during
the handover. RWO makes that impossible, which means no non-disruptive node maintenance.
This constrains more design decisions than anything else on the platform.

**NetworkPolicy does not apply to secondary interfaces.** It is enforced by the cluster CNI
on the pod's primary interface. A VM on a bridged VLAN bypasses your policies entirely, and
nothing warns you. See `lab03-networking/`.

## Questions

LinkedIn: linkedin.com/in/muhammad-umer-65213320b
