# Cluster requirements — read this first

These labs are written to run on **Single Node OpenShift**, because that is the smallest
and cheapest cluster that can host OpenShift Virtualization at all.

They work on a multi-node bare-metal cluster too, and more of them work *better*. Three
constraints are worth understanding before you start, whichever you have.

## 1. Single node

**What this means:**

| Works | Doesn't work |
|---|---|
| VM provisioning, lifecycle, hotplug | Live migration — nowhere to migrate to |
| Snapshots, clones, templates | Node drain with graceful eviction |
| OADP backup and restore | Multi-node scheduling |
| MTV namespace-to-namespace migration | MTV cluster-to-cluster |
| Multus secondary networks | Cross-node network testing |

Live migration and graceful node drain cannot be exercised on one node — there is nowhere
for a workload to move to. The manifests still carry the configuration you would use, so
they work unchanged once you have a second node.

## 2. Storage is ReadWriteOnce

The LVM Storage Operator is RWO only, and it is the usual choice for a single-node
cluster. **Your cluster may differ** — run `./scripts/configure.sh` and it will detect RWX
if your storage offers it.

On a single node this is academic for everything except live migration — there is only one
node for a volume to attach to. But if your storage is RWO, `accessMode: ReadWriteMany`
will **fail** to bind. That is why the manifests carry `CHANGE_ME_ACCESSMODE` rather than
a hardcoded value.

So if live migration is on your roadmap, the access mode your storage supports is the
first thing to establish — not the last.

## 3. Nested virtualization

If you are running nested — a single-node cluster inside a cloud VM or a workstation
hypervisor — VMs created in OpenShift sit two levels of nesting deep. Expect roughly 10%
slower CPU and noticeably slower disk than bare metal. Nested virtualization is fine for
learning the platform and is not supported for production.

Keep VMs small — **2 GB RAM, 1 vCPU** is plenty for exercising the platform and boots
quickly. The manifests here are sized accordingly. Scale them up on real hardware.

## 4. Budget your storage before you start

A host-assisted clone of a `Block` volume writes the **whole device**, not just the data in
it, so every 30Gi VM disk costs 30Gi of real space. Add to that the common boot images:
`enableCommonBootImageImport` pulls six of them at 30Gi each, which on a small cluster is
more than everything else combined.

Rough requirement to run all five labs without cleaning up in between: **~150Gi of usable
storage.** On less than that, either delete the boot images you don't use, or clean up each
lab's VMs and DataVolumes before starting the next.

```bash
NODE=$(oc get node -o name | head -1 | cut -d/ -f2)
oc debug node/$NODE -- chroot /host lvs -a          # LVMS: pool size and Data%
oc get dataimportcron -n openshift-virtualization-os-images
```

`reference/troubleshooting.md` has the procedure for disabling the boot images you don't
need, and what the failure looks like if you run out mid-clone.

---

## Before you run anything

```bash
# Fill in the placeholders first
./scripts/configure.sh --apply

# Cluster healthy?
oc get co --no-headers | awk '$3!="True" || $4!="False" || $5!="False"'

# Storage class present and default?
oc get sc

# Boot source ready? (this is the most common blocker)
oc get datasource -n openshift-virtualization-os-images rhel9 \
  -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}{"\n"}'
```

If the `rhel9` DataSource isn't `True`, VM creation will hang at the DataVolume stage. See
`lab02-vms/README.md` for the fallback.

## After the cluster has been powered off and back on

Give it ten minutes, then:

```bash
./scripts/health.sh
```

If nodes are `NotReady` and CSRs are pending, see `reference/troubleshooting.md`.
