#!/usr/bin/env bash
# Attach a disk to a running VM without restarting the guest.
set -eu
VM=${1:-rhel9-web01}
NS=${2:-production-vms}
VOL=${3:-data01}

echo "== Before =="
virtctl ssh cloud-user@$VM -n $NS --local-ssh-opts="-o StrictHostKeyChecking=no" \
  -c "lsblk" 2>/dev/null || echo "(use: virtctl console $VM -n $NS, then lsblk)"

echo
echo "== Hotplugging $VOL with --persist =="
echo "   Without --persist the disk vanishes on the next restart."
virtctl addvolume "$VM" --volume-name="$VOL" --persist -n "$NS"

sleep 3
echo
echo "== After — the new device should be present, no reboot =="
echo "   virtctl console $VM -n $NS   then:  lsblk"
