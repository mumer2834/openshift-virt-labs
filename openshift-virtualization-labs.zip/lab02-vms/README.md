# Lab 2 — Build a VM from the CLI and hotplug a disk

```bash
oc apply -f 01-namespace.yaml
oc apply -f 02-vm-rhel9.yaml

# Disk import first — this is where problems surface, not on the VM
oc get dv -n production-vms -w

# Then the instance
oc get vmi -n production-vms -w
```

Get inside:

```bash
virtctl console rhel9-web01 -n production-vms    # Ctrl+] to exit
# login: cloud-user / redhat
```

Confirm the guest agent came up — you need it in Lab 4 for consistent backups:

```bash
virtctl guestosinfo rhel9-web01 -n production-vms
```

Hotplug:

```bash
oc apply -f 03-dv-data01.yaml
oc get dv data01 -n production-vms -w

virtctl addvolume rhel9-web01 --volume-name=data01 --persist -n production-vms
```

Inside the guest:

```bash
lsblk                        # note the new device name
sudo mkfs.xfs /dev/<dev>
sudo mkdir -p /data
sudo mount /dev/<dev> /data
echo "hello" | sudo tee /data/marker.txt
```

Prove `--persist` worked:

```bash
virtctl restart rhel9-web01 -n production-vms
# wait for Running, reconnect, lsblk — the disk is still there
```

## If the DataVolume hangs in Pending

Most common failure here. Check in this order:

```bash
oc get sc                                              # is there a default?
oc describe dv rhel9-web01-root -n production-vms      # read the events
oc get datasource -n openshift-virtualization-os-images rhel9
```

**If the `rhel9` DataSource doesn't exist or isn't Ready**, the boot source import hasn't
finished (or can't reach the registry). Fallback — import directly:

```yaml
# Replace the sourceRef block in 02-vm-rhel9.yaml with:
  source:
    registry:
      url: docker://registry.redhat.io/rhel9/rhel-guest-image:latest
```

That needs a pull secret for registry.redhat.io. Check the import pod if it stalls:

```bash
oc logs -n production-vms -l cdi.kubevirt.io=importer --tail=50
```

## Teaching points

- **Device names vary.** Some runs give `sda`, some `vdb`. That is exactly why production
  systems mount by UUID and never by device path.
- **`--persist` is not optional.** Without it the disk works, then vanishes on the next
  restart — typically three weeks later during patching.
- **Watch the DataVolume, not the VM.** Import progress, conversion errors and space
  problems all surface there first.
