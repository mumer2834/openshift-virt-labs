# Lab 1 — Deploy the operator and verify the control plane

```bash
oc apply -f 01-namespace.yaml
oc apply -f 02-operatorgroup.yaml
oc apply -f 03-subscription.yaml

oc get csv -n openshift-cnv -w        # wait for Succeeded, Ctrl+C

oc apply -f 04-hyperconverged.yaml

./verify.sh
```

## What healthy looks like

- CSV phase `Succeeded`
- All three HyperConverged conditions: `Available=True`, `Progressing=False`, `Degraded=False`
- Roughly 20–30 pods in `openshift-cnv`
- At least one node carrying `kubevirt.io/schedulable=true`
- `virt-handler` appears once per node — it's a DaemonSet, not a Deployment

## Where it goes wrong

| Symptom | Cause |
|---|---|
| `virt-handler` CrashLoopBackOff | No virtualization extensions on that node |
| Stuck at `Progressing=True` | An operand can't reconcile — read `status.conditions` messages |
| Applied the HCO CR too early | The CRD didn't exist yet. Reapply; harmless |
| No `kubevirt.io/schedulable` node | The node can't see `/dev/kvm`. Bare metal: enable VT-x/AMD-V in firmware. Nested: the node VM needs host CPU passthrough, and nested virtualization enabled on the hypervisor |
| Namespace named something else | Several components assume `openshift-cnv`. Start over |

## The three objects

Confusing these wastes more troubleshooting time than anything else:

```bash
oc get vm      # definition   — persistent. Config problems live here.
oc get vmi     # instance     — ephemeral. Runtime problems live here.
oc get pod     # virt-launcher — the real process. Resource problems live here.
```
