#!/usr/bin/env bash
# Post-install smoke test. This belongs in your runbook.
set -u
echo "== CSV (want Succeeded) =="
oc get csv -n openshift-cnv -o custom-columns=NAME:.metadata.name,PHASE:.status.phase --no-headers
echo
echo "== HyperConverged conditions =="
echo "   want: Available=True  Progressing=False  Degraded=False"
oc get hyperconverged kubevirt-hyperconverged -n openshift-cnv \
  -o jsonpath='{range .status.conditions[*]}   {.type}={.status}{"\n"}{end}'
echo
echo "== Pods =="
oc get pods -n openshift-cnv --no-headers | awk '{print $1, $3}' | sort | uniq -c | sort -rn | head
echo
echo "== Will this node accept a VM? (empty = the node cannot see /dev/kvm) =="
oc get nodes -l kubevirt.io/schedulable=true
