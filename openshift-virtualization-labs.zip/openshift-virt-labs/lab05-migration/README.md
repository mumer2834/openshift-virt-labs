# Lab 5 — Migrating a workload with MTV

**This lab migrates a VM between namespaces on the same cluster**, using MTV's OpenShift
provider. That keeps it runnable with one cluster.

The objects and the workflow are identical to a cluster-to-cluster migration — only the
Provider URL and credential differ. See `08-provider-remote.yaml` for exactly what changes,
including the vSphere case.

## Run it

```bash
# Operator
oc apply -f 00-install-mtv.yaml
oc get csv -n openshift-mtv -w
oc apply -f 01-forkliftcontroller.yaml

# 'host' registers itself — this is your destination provider
oc get provider -n openshift-mtv

# Source workload
oc apply -f 02-namespaces.yaml
oc apply -f 03-vm-staging.yaml
oc get vmi -n staging-vms -w

# Maps
oc apply -f 04-networkmap.yaml
oc apply -f 05-storagemap.yaml

# Plan — wait for validation BEFORE running
oc apply -f 06-plan.yaml
oc get plan migrate-web-tier -n openshift-mtv -o jsonpath='{.status.conditions}' | jq

# Go
oc apply -f 07-migration.yaml
oc get plan migrate-web-tier -n openshift-mtv \
  -o jsonpath='{.status.migration.vms[*].phase}{"\n"}'
```

## Verify on the far side

```bash
oc get vm,vmi -n migrated-vms
virtctl console rhel9-staging01 -n migrated-vms      # data intact?

# The question that matters for the future:
oc get vmi rhel9-staging01 -n migrated-vms \
  -o jsonpath='{.status.conditions[?(@.type=="LiveMigratable")]}{"\n"}'
```

On RWO storage that returns `False`. **That is not a bug — it is the consequence of the
access mode you chose in `05-storagemap.yaml`.** With RWX storage and
`accessMode: ReadWriteMany`, it returns `True` and every migrated VM stays patchable
without downtime.

## The five objects

| Object | What it is |
|---|---|
| **Provider** | A connection to an environment. You need two: source and destination |
| **NetworkMap** | Source network → destination network |
| **StorageMap** | Source storage → destination StorageClass. **Where you set access mode** |
| **Plan** | VMs + the two maps + a target namespace. Reusable, validated before running |
| **Migration** | One execution of a Plan. Re-runnable if it fails partway |

## Migration types

| Type | Downtime | Available from |
|---|---|---|
| Cold | Full copy duration | All supported sources |
| Warm | Minutes — final delta only | vSphere, oVirt |
| Live | Effectively none | **OpenShift to OpenShift only** |

Warm migration does **not** mean zero downtime. The final cutover still stops the VM
briefly, so plan for minutes of downtime, not none.

Notes:

- **Warm from vSphere** needs Changed Block Tracking (CBT) enabled on the VMs and disks.
- **VDDK** is optional but strongly recommended for cold migration from vSphere, and
  required for warm migration and for VMs on vSAN.
- **Live migration between OpenShift clusters** is generally available from OpenShift
  Virtualization 4.21 (Technology Preview in 4.20). It needs matching versions on both
  clusters, the decentralized live migration feature enabled on both, and network
  connectivity between their migration networks. It's run as an MTV plan of type Live.
- **There is no live migration from vSphere**, and MTV doesn't migrate back from OpenShift
  to vSphere — keep source VMs until you're confident, so rollback is a power-on.
- This lab migrates **between namespaces on one cluster**, cold. The objects and workflow
  are the same as for a cross-cluster or vSphere migration; only the source Provider
  changes.

## After the migration — the checklist most guides skip

```bash
# 1. Boots, and is the guest agent running?
virtctl guestosinfo rhel9-staging01 -n migrated-vms

# 2. Disk bus — converted VMs sometimes land on SATA/IDE for bootability.
#    Moving to virtio is a real performance difference.
oc get vm rhel9-staging01 -n migrated-vms -o jsonpath='{.spec.template.spec.domain.devices.disks}' | jq

# 3. Network identity — MAC, IP, and anything downstream keyed to them
oc get vmi rhel9-staging01 -n migrated-vms -o jsonpath='{.status.interfaces}' | jq

# 4. Can it live-migrate?
oc get vmi rhel9-staging01 -n migrated-vms \
  -o jsonpath='{.status.conditions[?(@.type=="LiveMigratable")]}{"\n"}'
```

**And re-apply the things that don't travel:** NetworkPolicy, quotas, RBAC, monitoring,
backup schedules. The VM moved; the surrounding configuration did not. This is what bites
hardest in practice — people treat migration as done when the VM boots, then discover a
week later that the workload has no backup schedule because that was defined against the
old namespace.

## Where it goes wrong

| Symptom | Cause |
|---|---|
| Plan stuck at validation | Something unmapped. The message names it — read it rather than guessing |
| Migration fails at copy | Target storage class doesn't exist, or can't satisfy the access mode |
| Migrated fine, `LiveMigratable=False` | `accessMode: ReadWriteOnce`. You migrated a constraint along with the data |
| Destination NAD not found | MTV maps onto existing NADs, it doesn't create them. Build networks first |
