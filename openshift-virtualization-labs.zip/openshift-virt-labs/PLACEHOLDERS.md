# Placeholders — set these for YOUR cluster

Every manifest in this repo uses `CHANGE_ME_*` for the handful of values that genuinely
differ between clusters. **Run `./scripts/configure.sh` and it fills them in for you**, or
substitute them by hand using the table below.

Nothing else needs changing.

If you substitute by hand, note that `accessModes` is a **list**. Every file writes it as

```yaml
accessModes:
  - CHANGE_ME_ACCESSMODE
```

so replacing just the placeholder word is always safe. `accessModes: ReadWriteOnce` on one
line is a string, not a list, and the API rejects it — with a confusing error that blames
a webhook rather than the field.

| Placeholder | What it is | Find yours with |
|---|---|---|
| `CHANGE_ME_STORAGECLASS` | The StorageClass VM disks are provisioned from | `oc get sc` |
| `CHANGE_ME_SOURCE_STORAGECLASS` | MTV only: the *source* storage class being migrated from | `oc get sc` |
| `CHANGE_ME_ACCESSMODE` | `ReadWriteMany` or `ReadWriteOnce` | see below |
| `CHANGE_ME_VOLUMEMODE` | `Block` or `Filesystem` | see below |
| `CHANGE_ME_BRIDGE_NIC` | Lab 3 only: the NIC to bridge for secondary networking | see below |
| `CHANGE_ME_NODE_VM_NAME` | Lab 3, optional: only if you run `00-add-second-nic.sh` | `sudo virsh list --all` |

---

## CHANGE_ME_ACCESSMODE — the one that matters

**`ReadWriteMany` if your storage supports it. `ReadWriteOnce` if not.**

This is not a formality. RWX is what makes live migration possible, because two
virt-launcher pods hold the volume during the handover. Without it you have no
non-disruptive node maintenance — and you find out at your first maintenance window,
not today.

Check what your storage offers:

```bash
# What provisioners do you have?
oc get sc -o custom-columns=NAME:.metadata.name,PROVISIONER:.provisioner

# Does a class already serve RWX volumes anywhere?
oc get pvc -A -o custom-columns=NS:.metadata.namespace,NAME:.metadata.name,\
MODE:.spec.accessModes[0],SC:.spec.storageClassName | grep RWX
```

Rough guide by provisioner:

| Storage | RWX? |
|---|---|
| ODF / Ceph RBD | Yes in **Block** volume mode (the `ocs-storagecluster-ceph-rbd-virtualization` class) — this is the usual choice for VM disks |
| ODF / CephFS | Yes (Filesystem mode) — less common for VM disks |
| NFS-backed classes | Yes |
| LVM Storage Operator (LVMS) | **No** — RWO only |
| Most cloud block storage (EBS, PD, Azure Disk) | No |
| Portworx, Trident (NFS mode), many enterprise arrays | Usually yes |

If you're unsure, start with `ReadWriteOnce` — everything in this repo works except live
migration, and you'll get a clear error rather than silent breakage.

## CHANGE_ME_VOLUMEMODE

**`Block` for most VM workloads.** It hands the guest a raw device, which is faster and
is what OpenShift Virtualization expects by default.

Use `Filesystem` if your storage doesn't support block volumes — a disk image file gets
stored inside a filesystem PVC instead. Slower, and it rules out some snapshot paths.

```bash
oc get storageprofile <your-class> -o yaml | grep -A10 claimPropertySets
```

That shows the volume and access modes CDI considers valid for your provisioner.

## CHANGE_ME_BRIDGE_NIC

**Lab 3 only.** The physical interface on your nodes that carries the VLAN trunk you want
VMs to reach.

```bash
NODE=$(oc get node -o name | head -1 | cut -d/ -f2)
oc debug node/$NODE -- chroot /host ip -br link
```

**Pick a spare NIC, not the one carrying the cluster network.** Bridging your node's
primary interface will cut it off from the cluster.

If your nodes only have one NIC, `lab03-networking/00-add-second-nic.sh` adds one — but
only for the case where your node is a libvirt VM on a hypervisor you administer. That is
the script's `CHANGE_ME_NODE_VM_NAME`. On bare metal or managed infrastructure, add an
interface however that platform does it and come back to this step.

---

## Automatic configuration

```bash
./scripts/configure.sh            # detects and shows what it would set
./scripts/configure.sh --apply    # writes the values into the manifests
```

It auto-detects your default StorageClass and checks whether block volumes are supported.
Access mode and bridge NIC it will ask about, because guessing those wrong is worse than
asking.

To reset back to placeholders at any point:

```bash
git checkout -- .
```
