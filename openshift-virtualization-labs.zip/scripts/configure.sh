#!/usr/bin/env bash
#
# Fill in the CHANGE_ME_* placeholders for your cluster.
#
#   ./scripts/configure.sh           show what would be set
#   ./scripts/configure.sh --apply   write it into the manifests
#
# Reset at any time with:  git checkout -- .
#
set -euo pipefail
cd "$(dirname "$0")/.."

APPLY=false
[ "${1:-}" = "--apply" ] && APPLY=true

echo "== Detecting cluster values =="

# --- storage class -----------------------------------------------------------
SC=$(oc get sc -o jsonpath='{.items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")].metadata.name}' 2>/dev/null || true)
if [ -z "$SC" ]; then
  SC=$(oc get sc -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
  [ -n "$SC" ] && echo "   ! no default StorageClass; using first found"
fi
if [ -z "$SC" ]; then
  echo "   ! no StorageClass found — set CHANGE_ME_STORAGECLASS by hand"
  SC="CHANGE_ME_STORAGECLASS"
fi
echo "   StorageClass:  $SC"

# --- volume mode -------------------------------------------------------------
VOLMODE=Block
if oc get storageprofile "$SC" -o yaml 2>/dev/null | grep -q 'volumeMode: Filesystem'; then
  if ! oc get storageprofile "$SC" -o yaml 2>/dev/null | grep -q 'volumeMode: Block'; then
    VOLMODE=Filesystem
  fi
fi
echo "   volumeMode:    $VOLMODE"

# --- access mode -------------------------------------------------------------
ACCESS=""
if oc get storageprofile "$SC" -o yaml 2>/dev/null | grep -q 'ReadWriteMany'; then
  ACCESS=ReadWriteMany
  echo "   accessMode:    $ACCESS   (storage profile advertises RWX)"
else
  ACCESS=ReadWriteOnce
  echo "   accessMode:    $ACCESS   (no RWX advertised — live migration will not work)"
fi

# --- bridge NIC --------------------------------------------------------------
NIC="${OCP_BRIDGE_NIC:-CHANGE_ME_BRIDGE_NIC}"
if [ "$NIC" = "CHANGE_ME_BRIDGE_NIC" ]; then
  echo "   bridge NIC:    not set — Lab 3 only."
  echo "                  Set it with:  OCP_BRIDGE_NIC=ens4 $0 --apply"
else
  echo "   bridge NIC:    $NIC"
fi

echo
if ! $APPLY; then
  echo "Nothing written. Re-run with --apply to substitute these values."
  exit 0
fi

echo "== Writing into manifests =="
FILES=$(grep -rl 'CHANGE_ME_' --include='*.yaml' . || true)
[ -z "$FILES" ] && { echo "   no placeholders left"; exit 0; }

for f in $FILES; do
  sed -i \
    -e "s/CHANGE_ME_SOURCE_STORAGECLASS/${SC}/g" \
    -e "s/CHANGE_ME_STORAGECLASS/${SC}/g" \
    -e "s/CHANGE_ME_ACCESSMODE/${ACCESS}/g" \
    -e "s/CHANGE_ME_VOLUMEMODE/${VOLMODE}/g" \
    "$f"
  [ "$NIC" != "CHANGE_ME_BRIDGE_NIC" ] && sed -i -e "s/CHANGE_ME_BRIDGE_NIC/${NIC}/g" "$f"
  echo "   $f"
done

echo
echo "== Remaining placeholders =="
grep -rn 'CHANGE_ME_' --include='*.yaml' . || echo "   none"

cat > values.env <<ENV
# Written by scripts/configure.sh on $(date -u +%Y-%m-%dT%H:%M:%SZ)
STORAGECLASS=${SC}
ACCESSMODE=${ACCESS}
VOLUMEMODE=${VOLMODE}
BRIDGE_NIC=${NIC}
ENV
echo
echo "Recorded in values.env"
ENV_NOTE=1
