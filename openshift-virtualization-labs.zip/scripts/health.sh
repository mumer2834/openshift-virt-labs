#!/usr/bin/env bash
# Cluster readiness check. Run before working through the labs,
# and after any restart.
set -u
echo "=== Nodes ==="
oc get nodes
echo
echo "=== Degraded / progressing operators (empty = good) ==="
oc get co --no-headers 2>/dev/null | awk '$3!="True" || $4!="False" || $5!="False"'
echo
echo "=== Pending CSRs (should be 0 after a cold start) ==="
oc get csr --no-headers 2>/dev/null | grep -c Pending || echo 0
echo
echo "=== Node accepts VMs? ==="
oc get nodes -l kubevirt.io/schedulable=true --no-headers 2>/dev/null | wc -l
echo
echo "=== Storage ==="
oc get sc 2>/dev/null
oc get volumesnapshotclass --no-headers 2>/dev/null | wc -l | xargs echo "VolumeSnapshotClasses:"
echo
echo "=== Boot source ==="
oc get datasource -n openshift-virtualization-os-images rhel9 \
  -o jsonpath='rhel9 Ready={.status.conditions[?(@.type=="Ready")].status}{"\n"}' 2>/dev/null \
  || echo "rhel9 DataSource NOT FOUND"
echo
echo "=== Backup target ==="
oc get backupstoragelocation -n openshift-adp --no-headers 2>/dev/null || echo "OADP not installed"
echo
echo "=== Running VMs ==="
oc get vmi -A --no-headers 2>/dev/null || echo "none"
