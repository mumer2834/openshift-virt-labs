#!/usr/bin/env bash
# Run after powering the cluster back on. Approves the CSR backlog that
# builds up while the node was shut down.
#
# Run this ON A CONTROL-PLANE NODE as root, not from your workstation. The
# normal kubeconfig won't authenticate while the cluster is in this state;
# the localhost-recovery one bypasses the aggregated API:
#   ssh core@<node-address>
#   sudo -i
#   export KUBECONFIG=/etc/kubernetes/static-pod-resources/kube-apiserver-certs/secrets/node-kubeconfigs/localhost-recovery.kubeconfig
set -u

approve() {
  oc get csr -o go-template='{{range .items}}{{if not .status}}{{.metadata.name}}{{"\n"}}{{end}}{{end}}' \
    | xargs --no-run-if-empty oc adm certificate approve
}

echo "Approval pass 1"; approve; sleep 45
echo "Approval pass 2"; approve; sleep 45
echo "Approval pass 3"; approve

echo
echo "Remaining pending:"
oc get csr --no-headers | grep Pending | wc -l
echo
oc get nodes
