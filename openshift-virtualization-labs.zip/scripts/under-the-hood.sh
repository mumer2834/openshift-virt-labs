#!/usr/bin/env bash
#
# Look underneath a running VM: the Kubernetes objects, the virt-launcher
# pod, the container inside it, libvirt, and finally the qemu-kvm process
# as the node sees it. Read-only -- this changes nothing.
#
#   ./scripts/under-the-hood.sh <vm-name> [namespace]
#   PAUSE=1 ./scripts/under-the-hood.sh <vm-name> [namespace]
#
# PAUSE=1 waits for Enter before each step, so you can talk through each
# one. Step 9 uses `oc debug node`, which needs cluster-admin.
#
# Interface names, socket paths and helper containers vary between
# versions. Every step prints what it finds rather than assuming.
set -u

VM=${1:?usage: $0 <vm-name> [namespace]}
NS=${2:-$(oc project -q)}
PAUSE=${PAUSE:-0}

step() {
  if [ "$PAUSE" = 1 ]; then printf '\n'; read -rp '  [enter] ' _; fi
  printf '\n\033[1;36m== %s ==\033[0m\n' "$*"
}
note() { printf '\033[2m   %s\033[0m\n' "$*"; }
pretty() { if command -v jq >/dev/null 2>&1; then jq .; else cat; echo; fi; }

# ---------------------------------------------------------------------------
step "1. One virtual machine, three Kubernetes objects"
oc get vm "$VM" -n "$NS" || exit 1
if ! oc get vmi "$VM" -n "$NS"; then
  echo "No VMI -- the VM is not running. Start it first:  virtctl start $VM -n $NS"
  exit 1
fi
POD=$(oc get pod -n "$NS" -l kubevirt.io=virt-launcher --no-headers \
        -o custom-columns=NAME:.metadata.name | grep "^virt-launcher-${VM}-" | head -1)
if [ -z "$POD" ]; then echo "No virt-launcher pod found for $VM"; exit 1; fi
NODE=$(oc get pod "$POD" -n "$NS" -o jsonpath='{.spec.nodeName}')
oc get pod "$POD" -n "$NS" -o wide
note "VM: what you declared.  VMI: the fact that it is running.  Pod: where it runs."

in_pod() { oc exec -n "$NS" "$POD" -c compute -- "$@"; }

# ---------------------------------------------------------------------------
step "2. What is in the pod"
oc get pod "$POD" -n "$NS" \
  -o jsonpath='{range .spec.containers[*]}  {.name}{"\t"}{.image}{"\n"}{end}'
note "'compute' holds libvirt and qemu-kvm. Anything else is a helper."

# ---------------------------------------------------------------------------
step "3. What the pod asked the scheduler for"
oc get pod "$POD" -n "$NS" \
  -o jsonpath='{.spec.containers[?(@.name=="compute")].resources}' | pretty
GM=$(oc get vmi "$VM" -n "$NS" -o jsonpath='{.status.memory.guestAtBoot}')
[ -z "$GM" ] && GM=$(oc get vmi "$VM" -n "$NS" -o jsonpath='{.spec.domain.memory.guest}')
echo "   guest memory: ${GM:-not reported}"
note "Compare the memory request with the guest memory. The difference is per-VM overhead."
note "devices.kubevirt.io/kvm is requested like any other device -- a GPU works the same way."

# ---------------------------------------------------------------------------
step "4. The node advertises KVM as a schedulable resource"
oc get node "$NODE" -o jsonpath='{.status.allocatable}' \
  | tr ',{}' '\n\n\n' | grep -i 'devices.kubevirt.io' || echo "   (none -- this node cannot run VMs)"
note "virt-handler is the device plugin that puts these here."
note "No /dev/kvm on the node means no entry, and the scheduler has nowhere to put the pod."

# ---------------------------------------------------------------------------
step "5. Inside the container: the device nodes qemu needs"
in_pod ls -l /dev/kvm /dev/net/tun /dev/vhost-net 2>&1
note "/dev/kvm is the hardware virtualization interface, passed into an otherwise ordinary container."

# ---------------------------------------------------------------------------
step "6. Inside the container: the process tree"
T=$(mktemp)
if in_pod ps -eo pid,user,rss,args >"$T" 2>/dev/null; then
  cut -c1-170 "$T"
else
  in_pod sh -c 'for p in /proc/[0-9]*; do printf "%-7s" "${p#/proc/}"; tr "\0" " " < "$p/cmdline" 2>/dev/null; echo; done' \
    | cut -c1-170
fi
rm -f "$T"
note "virt-launcher supervises libvirt, libvirt runs qemu-kvm. The VM is that qemu-kvm line."

# ---------------------------------------------------------------------------
step "7. Libvirt's view, from inside the pod"
FOUND=0; URI=""
for u in "" \
         "qemu+unix:///session?socket=/var/run/libvirt/virtqemud-sock" \
         "qemu+unix:///session?socket=/var/run/libvirt/libvirt-sock" \
         "qemu+unix:///system?socket=/var/run/libvirt/libvirt-sock"; do
  a=(); [ -n "$u" ] && a=(-c "$u")
  if in_pod virsh ${a[@]+"${a[@]}"} list --all >/dev/null 2>&1; then FOUND=1; URI=$u; break; fi
done
if [ "$FOUND" = 1 ]; then
  vsh() { local a=(); [ -n "$URI" ] && a=(-c "$URI"); in_pod virsh ${a[@]+"${a[@]}"} "$@"; }
  vsh list --all
  DOM=$(vsh list --all --name | grep -v '^$' | head -1)
  echo
  note "domain XML for $DOM (excerpt):"
  vsh dumpxml "$DOM" \
    | grep -E "^<domain|<name>|<memory|<vcpu|<type |<emulator>|<disk type|<source (file|dev)=|<interface type|<model type" \
    | head -25
  note "One domain per pod. Domain type kvm, emulator qemu-kvm -- the libvirt you'd run on any RHEL host."
else
  note "virsh could not reach libvirt with the known socket paths on this version. Sockets present:"
  in_pod ls -l /var/run/libvirt/ 2>&1
fi

# ---------------------------------------------------------------------------
step "8. Inside the container: the network plumbing"
in_pod ls /sys/class/net
note "k6t-* are bridges KubeVirt builds inside the pod; tap* is the VM's virtual NIC."
note "One bridge per VM interface. A second network means a second bridge here."

# ---------------------------------------------------------------------------
step "9. The same VM from the node: just a Linux process"
oc debug node/"$NODE" -- chroot /host sh -c "
P=\$(pgrep -f 'gues[t]=${NS}_${VM}' | head -1)
if [ -z \"\$P\" ]; then
  echo 'Not matched by name. All qemu-kvm processes on this node:'
  ps -eo pid,user,rss,args | grep '[q]emu-kvm' | cut -c1-150
  exit 0
fi
echo \"host PID: \$P\"
ps -o pid,user,rss,etime,args -p \$P | cut -c1-150
echo; echo 'SELinux label:'; ps -o label= -p \$P
echo; echo 'cgroup:';        cat /proc/\$P/cgroup
" 2>&1 | grep -vE '^(Starting pod|Removing debug pod|To use host binaries|Temporary namespace|$)'
note "Look at the user, the SELinux label, and the cgroup path."
note "It is accounted under kubepods, like any container -- because to the node, it is one."

echo
note "A virtual machine here is a Kubernetes object that happens to run QEMU."
