#!/usr/bin/env bash
# Collect the version strings that go in README.md and on the slides.
set -u
echo "OpenShift:  $(oc get clusterversion -o jsonpath='{.items[0].status.desired.version}' 2>/dev/null)"
for ns in openshift-cnv openshift-mtv openshift-adp openshift-storage; do
  v=$(oc get csv -n $ns -o jsonpath='{.items[0].spec.version}' 2>/dev/null)
  n=$(oc get csv -n $ns -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
  [ -n "$n" ] && printf "%-18s %s (%s)\n" "$ns:" "$v" "$n"
done
echo
echo "Storage classes:"
oc get sc -o custom-columns=NAME:.metadata.name,PROVISIONER:.provisioner,DEFAULT:.metadata.annotations.'storageclass\.kubernetes\.io/is-default-class' --no-headers 2>/dev/null
