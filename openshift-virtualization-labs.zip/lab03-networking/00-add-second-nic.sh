#!/usr/bin/env bash
#
# OPTIONAL — only needed if your cluster nodes have a single NIC.
#
# Bridging the interface that carries the cluster API will cut the node off
# the network and take the cluster down with it. If your nodes already have
# a spare interface, skip this script entirely and bridge that one.
#
# This script covers the common home-lab case: the cluster node is a libvirt
# VM on a hypervisor you control. It creates an isolated libvirt network and
# attaches a second NIC to the node from it.
#
#   RUN THIS ON THE HYPERVISOR, NOT ON THE CLUSTER.
#
# If your nodes are bare metal, a cloud instance, or run on a hypervisor you
# do not administer, this script does not apply — add an interface by whatever
# means that platform provides, then continue from step 2 in the README.
#
set -eu

# ---- set these for your environment ----------------------------------------
VM="${VM:-CHANGE_ME_NODE_VM_NAME}"   # libvirt domain name of the cluster node
NET="${NET:-labvlan}"                # libvirt network this script creates
BRIDGE="${BRIDGE:-virbr-lab}"        # host bridge name for that network
MAC="${MAC:-52:54:00:11:22:33}"      # pinned so you can find the NIC by MAC
# ----------------------------------------------------------------------------

if [ "$VM" = "CHANGE_ME_NODE_VM_NAME" ]; then
  echo "ERROR: set VM to your node's libvirt domain name first."
  echo
  echo "  sudo virsh list --all          # find it"
  echo "  VM=<domain-name> $0            # then re-run"
  exit 1
fi

if ! sudo virsh dominfo "$VM" >/dev/null 2>&1; then
  echo "ERROR: no libvirt domain named '$VM'. Check: sudo virsh list --all"
  exit 1
fi

echo "== Creating isolated libvirt network '$NET' =="
cat > /tmp/${NET}.xml <<XML
<network>
  <name>${NET}</name>
  <bridge name='${BRIDGE}' stp='on' delay='0'/>
  <!-- No <forward> element: isolated, so no NAT and no route out.
       No <ip> element: libvirt starts no DHCP server on it.
       Both are deliberate. VM addresses come from cloud-init in
       03-vm-dual-nic.yaml, and a NIC with no DHCP cannot install a
       second default route on your node. -->
</network>
XML

sudo virsh net-define /tmp/${NET}.xml 2>/dev/null || echo "  (already defined)"
sudo virsh net-start ${NET}     2>/dev/null       || echo "  (already running)"
sudo virsh net-autostart ${NET}
sudo virsh net-list --all | grep -E "Name|${NET}"

echo
echo "== Attaching a second NIC to ${VM} =="
# --live applies it to the running VM, --config persists it in the domain XML.
# No reboot needed, which matters when the cluster is a single node.
sudo virsh attach-interface "${VM}" network "${NET}" \
  --model virtio --mac "${MAC}" --live --config 2>/dev/null \
  || echo "  (already attached, or the VM is off — if off, --config alone is enough)"

echo
echo "== Interfaces on ${VM} =="
sudo virsh domiflist "${VM}"

cat <<MSG

== Next: find the interface name INSIDE the node ==

Match on the pinned MAC rather than guessing which NIC is which:

  NODE=\$(oc get node -o name | head -1 | cut -d/ -f2)
  oc debug node/\$NODE -- chroot /host ip -br link | grep -i ${MAC}

Put that interface name in 01-nncp-bridge.yaml (CHANGE_ME_BRIDGE_NIC).

Interface names come from the PCI slot, so re-check it if you ever detach
and re-attach the NIC.

To undo this:
  sudo virsh detach-interface ${VM} network --mac ${MAC} --live --config
MSG
