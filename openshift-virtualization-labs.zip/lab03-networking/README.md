# Lab 3 — Secondary networks and the NetworkPolicy trap

## Before you start — pick the right interface

Bridging a node's **primary** NIC will cut it off from the cluster. On production hardware
you bridge a spare interface carrying your VLAN trunk, and add `"vlan": 120` to the NAD.

If your nodes only have one NIC — common on a single-node cluster — you need to add a
second one before you can do this lab safely. How depends on where your nodes run:

| Your nodes are | Add an interface by |
|---|---|
| libvirt VMs on a hypervisor you administer | `00-add-second-nic.sh` (run it **on the hypervisor**) |
| Bare metal | Installing/enabling a second NIC |
| A cloud instance or managed hypervisor | That platform's own network-interface controls |

The script is a convenience for the first case only. Everything from step 2 onward is
identical on any cluster.

## Two versions of the VM pair

| File | Root disk | Use it when |
|---|---|---|
| `03-vm-dual-nic.yaml` | 30Gi clone of the rhel9 DataSource, persistent | You have storage headroom and want a realistic VM |
| `03-vm-dual-nic-containerdisk.yaml` | Registry image, ephemeral, no PVC | Storage is tight, or you want it up in seconds |

The networking is identical in both. If clones sit at `CloneInProgress` and restart —
which means your storage ran out of real space, not that the clone is slow — use the
containerDisk version. This lab is about networking; the disk is incidental.

## Run it

```bash
# 1. ONLY if your node needs a second NIC, and only for libvirt nodes.
#    Run on the hypervisor. Attaches it live; no cluster reboot required.
VM=<your-node-domain-name> ./00-add-second-nic.sh

# 2. Find the new interface name inside the node.
#    Match on the MAC the script pinned — don't guess which NIC is which.
NODE=$(oc get node -o name | head -1 | cut -d/ -f2)
oc debug node/$NODE -- chroot /host ip -br link | grep -i 52:54:00:11:22:33

# 3. Put that name in 01-nncp-bridge.yaml, then:
oc apply -f 01-nncp-bridge.yaml
oc get nncp          # what you asked for
oc get nnce          # what actually happened, per node — read failures HERE

# 4. Publish it and attach two VMs
oc apply -f 02-nad-bridge.yaml
oc apply -f 03-vm-dual-nic.yaml                   # persistent disks, 30Gi clone each
#   or, if storage is tight:
# oc apply -f 03-vm-dual-nic-containerdisk.yaml   # no PVC, no clone, boots in ~20s
oc get vmi -n production-vms -w
```

## Prove the gap exists

```bash
virtctl console netdemo-a -n production-vms      # cloud-user / redhat
ip -br addr                                       # eth0 pod net, eth1 10.10.10.11
ping -c3 10.10.10.12                              # works
```

Now apply a namespace-wide default-deny and watch it change nothing:

```bash
oc apply -f 04-default-deny.yaml
oc get networkpolicy -n production-vms            # applied cleanly, no complaints
```

Back in the console, **ping again. It still works.**

**That is the point of this lab.** You wrote a default-deny policy, it applied cleanly, and
the VM is still reaching everything on the secondary network. Nothing warned you.

NetworkPolicy is enforced by the cluster CNI on the pod's **primary** interface. A
secondary Multus interface never goes through that path.

## Then watch the fix fail too

MultiNetworkPolicy is the control intended for secondary interfaces. Enable it — this
restarts the network operator pods, so give it a few minutes:

```bash
oc patch network.operator.openshift.io cluster --type=merge \
  -p '{"spec":{"useMultiNetworkPolicy":true}}'
oc get pods -n openshift-multus | grep networkpolicy      # wait for Running
```

```bash
oc apply -f 05-multinetworkpolicy.yaml
```

Ping again. **Still works.**

The policy only permits TCP/22, so ICMP should be denied outright. It isn't — because
MultiNetworkPolicy does not support linux-bridge:

| Supported | Not supported |
|---|---|
| SR-IOV (kernel NICs; not DPDK) | **linux-bridge** |
| MacVLAN | |
| IPVLAN | |
| Bond over SR-IOV | |
| OVN-Kubernetes secondary networks | |

Red Hat documents this. The Virtualization docs' table comparing Linux bridge CNI with an
OVN-Kubernetes localnet topology has a "Network policies" row reading **No** for bridge and
**Yes** for localnet, and there is a KB article titled *"Multi-Network Policy does not work
for Linux Bridge on OpenShift Virtualization"*.

### The failure is silent, and that is the real lesson

Nothing surfaces on the policy object. `oc describe` shows a healthy resource. The only
evidence is an INFO-level line in a daemonset log:

```bash
oc logs -n openshift-multus -l app=multus-networkpolicy \
  | grep -iE 'not supported|allowed networks'
```

```
INFO  Policy is affected by pod          pod=virt-launcher-netdemo-a-...
INFO  Network type is not supported      networkType=bridge
INFO  Failed to get allowed networks     valid plugins=["macvlan","sriov","ipvlan","bond"]
                                         error="no allowed networks found"
```

The controller found your pods, matched the selector, resolved the NAD — and then declined
to program anything.

## What to do instead

**Back the network with an OVN-Kubernetes localnet network** rather than linux-bridge CNI.
The VM spec keeps `bridge` binding; what changes is the network underneath, and enforcement
moves into OVN.

Two constraints:

- Use `ipBlock`. `podSelector` and `namespaceSelector` are not supported on OVN-K secondary
  networks.
- Those selectors also prevent live migration, so `ipBlock` is the right choice anyway.

**Switching the NAD to macvlan does not work for VMs.** KubeVirt's `bridge` binding moves
the pod interface's MAC onto the VM, which is precisely why macvlan and ipvlan break under
it. It is a valid answer for ordinary pods, not for virtual machines.

**Or decide the physical network owns that traffic.** Mid-migration this is often the
realistic answer — the VLAN already has firewalls and segmentation. That is a judgement
call rather than a documented Red Hat recommendation, and what matters is that it is a
decision someone made, not an accident.

Either way: raise it with your security team before they find it in an audit.

## Troubleshooting

| Symptom | Cause |
|---|---|
| VM won't start, network error | `interfaces` and `networks` names don't pair, or the NAD doesn't exist in that namespace |
| Second NIC exists but no address | `ipam: {}` means no address is assigned. Set it via cloud-init `networkData`, as these manifests do |
| NNCP shows Failed | Read `oc get nnce` — the per-node enactment has the real error |
| Wrong interface bridged, node unreachable | Set the interface `state: absent` in the NNCP and reconcile. This is why we used the second NIC |
| MultiNetworkPolicy applied, traffic still flows | Expected on a linux-bridge NAD — see above. Confirm with the multus-networkpolicy log |
| `oc get multinetworkpolicies` → no such resource type | The plural is `multi-networkpolicies`; try `oc get multi-networkpolicy -n <ns>` or `oc api-resources \| grep -i multinetwork` |
