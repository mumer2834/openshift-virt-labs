# Lab 3 — Secondary networks and the NetworkPolicy trap

## Before you start — pick the right interface

Bridging a node's **primary** NIC will cut it off from the cluster. On production hardware
you bridge a spare interface carrying your VLAN trunk, and add `"vlan": 120` to the NAD.

If your nodes only have one NIC — common on a single-node cluster — you need to add a
second one before you can do this lab safely. How depends on where your nodes run:

| Your nodes are | Add an interface by |
|---|---|
| libvirt VMs on a hypervisor you administer | `00-add-second-nic.sh` (run it **on the hypervisor**) |
| Bare metal | Installing/enabling a second NIC |
| A cloud instance or managed hypervisor | That platform's own network-interface controls |

The script is a convenience for the first case only. Everything from step 2 onward is
identical on any cluster.

## Two versions of the VM pair

| File | Root disk | Use it when |
|---|---|---|
| `03-vm-dual-nic.yaml` | 30Gi clone of the rhel9 DataSource, persistent | You have storage headroom and want a realistic VM |
| `03-vm-dual-nic-containerdisk.yaml` | Registry image, ephemeral, no PVC | Storage is tight, or you want it up in seconds |

The networking is identical in both. If clones sit at `CloneInProgress` and restart —
which means your storage ran out of real space, not that the clone is slow — use the
containerDisk version. This lab is about networking; the disk is incidental.

## Run it

```bash
# 1. ONLY if your node needs a second NIC, and only for libvirt nodes.
#    Run on the hypervisor. Attaches it live; no cluster reboot required.
VM=<your-node-domain-name> ./00-add-second-nic.sh

# 2. Find the new interface name inside the node.
#    Match on the MAC the script pinned — don't guess which NIC is which.
NODE=$(oc get node -o name | head -1 | cut -d/ -f2)
oc debug node/$NODE -- chroot /host ip -br link | grep -i 52:54:00:11:22:33

# 3. Put that name in 01-nncp-bridge.yaml, then:
oc apply -f 01-nncp-bridge.yaml
oc get nncp          # what you asked for
oc get nnce          # what actually happened, per node — read failures HERE

# 4. Publish it and attach two VMs
oc apply -f 02-nad-bridge.yaml
oc apply -f 03-vm-dual-nic.yaml                   # persistent disks, 30Gi clone each
#   or, if storage is tight:
# oc apply -f 03-vm-dual-nic-containerdisk.yaml   # no PVC, no clone, boots in ~20s
oc get vmi -n production-vms -w
```

## Prove the gap exists

```bash
virtctl console netdemo-a -n production-vms
# login cloud-user / redhat
ip addr                       # eth0 = pod network, eth1 = 10.10.10.11
ping -c3 10.10.10.12          # reaches netdemo-b
```

Now apply a default-deny policy for the whole namespace:

```bash
oc apply -f 04-default-deny.yaml
```

Back in the guest:

```bash
ping -c3 10.10.10.12          # STILL WORKS
```

**That is the point of this lab.** You wrote a default-deny policy, it applied cleanly, and
the VM is still reaching everything on the secondary network. Nothing warned you.

## The fix

```bash
oc patch network.operator.openshift.io cluster --type=merge \
  -p '{"spec":{"useMultiNetworkPolicy":true}}'
# wait for network operator pods to restart

oc apply -f 05-multinetworkpolicy.yaml
```

Often the right answer isn't MultiNetworkPolicy at all — it's recognising that the physical
network already has firewalls and segmentation, and documenting that as the design. What's
unacceptable is not knowing.

## Troubleshooting

| Symptom | Cause |
|---|---|
| VM won't start, network error | `interfaces` and `networks` names don't pair, or the NAD doesn't exist in that namespace |
| Second NIC exists but no address | `ipam: {}` means no address is assigned. Set it via cloud-init `networkData`, as these manifests do |
| NNCP shows Failed | Read `oc get nnce` — the per-node enactment has the real error |
| Wrong interface bridged, node unreachable | Set the interface `state: absent` in the NNCP and reconcile. This is why we used the second NIC |
